<?php
	
	/*
		The carousel has an aspect ratio of 16x9 by default, and 
		will scale on all devices accordingly. It's easy to create
		varying aspect ratio's if you need it, but I figured this
		would be easiest. Images DO NOT need to be the same size,
		it will scale to "contain".

		Custom Layouts:
			{{customCarouselLayout}}:
			example 1: cs-carousel-elementDisplay
			example 2: cs-carousel-imgPush

			

	*/

	// example data
	$listItems = array(
		array('title'=> 'Example 1', 'image' => '/images/image-1.jpg', 'caption' => 'basic desc'),
		array('title'=> 'Example 1', 'image' => '/images/image-2.jpg', 'bgColor'=> '#333', 'caption' => 'basic desc')
		);

?>


	<div id="" class="cs-carousel-container {{customCarouselLayout}}">
		<div id="{{carouselId}}" class="carousel slide" data-ride="carousel">
			<ol class="carousel-indicators">
			
						
						FOREACH $listItems
						{
							IF firstItem THEN class = "active";

							PRINT <li data-target="#{{carouselId}}" data-slide-to="{{count}}" class="{{class?}}"></li>
						}

			</ol>
			<div class="carousel-inner " role="listbox">

					FOREACH $listItems
					{
						IF firstItem THEN activeClass = 'active';
						IF isset($bgColor) THEN background = "background-color: $bgColor";

						PRINT>>

						<div class="item {{activeClasss?}}" style="{{background?}}">
							<div class="cs-carousel-img" style="background-image: url({{image}});">
							</div>
							<div class="carousel-caption">{{caption}}</div>
						</div>

						>>END
					}

			</div>
		</div>
		<a class="left carousel-control" href="#{{carouselId}}" role="button" data-slide="prev"><span class="glyphicon glyphicon-chevron-left"></span></a>
		<a class="right carousel-control" href="#{{carouselId}}" role="button" data-slide="next"><span class="glyphicon glyphicon-chevron-right"></span></a>

	</div>