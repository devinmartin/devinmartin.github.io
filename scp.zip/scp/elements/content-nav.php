
	<div class="cs-container">
		<div class="container">
			<ul class="nav nav-pills">

			 		FOREACH linkItem
					{
						IF currentPage THEN {{active}} = 'class="active"';
						PRINT <li role="presentation" {{active?}}><a href="{{url}}">{{linkName}}</a></li>

					}
			</ul>
		</div>
	</div>
			
					
						

